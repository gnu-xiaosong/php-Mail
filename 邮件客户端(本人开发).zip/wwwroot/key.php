<?php
//设置邮箱加密秘钥

//秘钥设定5个,这里可以自己增加
$setkey1='ftrcvbh';
$setkey2='mggfghgvv';
$setkey3='hgjhhpphhvvb';
$setkey4='jgfhhhbnjnn';
$setkey5='hgggfffbnn';
?>